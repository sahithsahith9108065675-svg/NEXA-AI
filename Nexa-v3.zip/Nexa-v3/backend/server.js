import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';

const app = express();
app.use(express.json({ limit: '64kb' }));
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM = `You are Nexa, a friendly, calm, concise Android voice assistant. Return ONLY valid JSON with this exact shape: {"reply":"string","actions":[...]}.
Allowed action objects:
- {"type":"global","name":"home|back|recents|notifications|quick_settings|lock_screen|screenshot|volume_up|volume_down"}
- {"type":"open_app","app":"youtube|chrome|settings|maps|whatsapp"}
- {"type":"open_url","url":"https://..."}
- {"type":"web_search","query":"..."}
Use actions only when the user clearly asks for a device action. Never invent a dangerous or irreversible action. For ordinary questions, actions should be []. Keep reply natural for speech. Do not claim an action happened unless it is represented in actions. If the user asks to open an app, use open_app. If they ask to search the web, use web_search. If they ask to go home/back/open notifications/quick settings/recents, use global. Multiple safe actions are allowed.`;

function cleanJson(text) {
  const s = String(text || '').trim().replace(/^```json/i, '').replace(/^```/i, '').replace(/```$/i, '').trim();
  const start = s.indexOf('{'), end = s.lastIndexOf('}');
  if (start >= 0 && end > start) return s.slice(start, end + 1);
  throw new Error('Model did not return JSON');
}

app.get('/health', (_req, res) => res.json({ ok: true, name: 'Nexa v3' }));

app.post('/chat', async (req, res) => {
  try {
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message) return res.status(400).json({ error: 'message required' });
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const input = [{ role: 'system', content: SYSTEM }, ...history, { role: 'user', content: message }];
    const response = await client.responses.create({ model: process.env.OPENAI_MODEL || 'gpt-6-luna', input });
    const parsed = JSON.parse(cleanJson(response.output_text));
    if (!Array.isArray(parsed.actions)) parsed.actions = [];
    res.json({ reply: String(parsed.reply || ''), actions: parsed.actions });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'AI request failed' });
  }
});

app.listen(Number(process.env.PORT || 8787), '0.0.0.0', () => console.log(`Nexa v3 backend on :${process.env.PORT || 8787}`));
