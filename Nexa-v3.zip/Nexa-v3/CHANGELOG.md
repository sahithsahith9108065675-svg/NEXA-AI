# Nexa v3 changes

- Replaced fixed-command demo behavior with a conversational AI backend.
- Added JSON action protocol between AI backend and Android app.
- Added voice -> AI -> action -> spoken response loop.
- Added session history.
- Added Settings screen for backend URL and Accessibility setup.
- Added allow-listed app launches and web search.
- Kept API credentials server-side.
