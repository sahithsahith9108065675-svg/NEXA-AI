package com.nexa.assistant

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private val client = OkHttpClient()
    private val sessionId = "nexa-" + System.currentTimeMillis()
    private val history = JSONArray()
    private val speakRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        chat = findViewById(R.id.chat); input = findViewById(R.id.input); status = findViewById(R.id.status)
        prefs = getSharedPreferences("nexa", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        findViewById<View>(R.id.sendButton).setOnClickListener { sendText() }
        findViewById<View>(R.id.micButton).setOnClickListener { startListening() }
        findViewById<View>(R.id.settingsButton).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        addBubble("Nexa", "Hey! I’m Nexa. Ask me something, or tell me what you want me to do on your phone.", false)
    }

    private fun sendText() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        input.setText(""); addBubble("You", text, true); askBackend(text)
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), speakRequest); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Nexa")
        }
        try { startActivityForResult(intent, speakRequest) } catch (_: Exception) { Toast.makeText(this, "Speech recognition isn't available on this device.", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Android callback API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speakRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) { input.setText(spoken); sendText() }
        }
    }

    private fun askBackend(text: String) {
        val base = prefs.getString("backend_url", "").orEmpty().trim().trimEnd('/')
        if (base.isBlank()) { addBubble("Nexa", "I’m ready, but my AI backend isn’t connected yet. Open Settings and add your backend URL.", false); return }
        status.text = "Thinking…"
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { callBackend(base, text) }
            status.text = "Ready"
            if (result == null) { addBubble("Nexa", "I couldn’t reach my AI server. Check the backend URL and internet connection.", false); return@launch }
            val reply = result.optString("reply", "I’m not sure how to respond to that.")
            addBubble("Nexa", reply, false); speak(reply)
            executeActions(result.optJSONArray("actions"))
        }
    }

    private fun callBackend(base: String, text: String): JSONObject? = try {
        val body = JSONObject().apply { put("session_id", sessionId); put("message", text); put("history", history) }
        val request = Request.Builder().url("$base/chat").post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val obj = JSONObject(response.body?.string().orEmpty())
            history.put(JSONObject().put("role", "user").put("content", text))
            history.put(JSONObject().put("role", "assistant").put("content", obj.optString("reply")))
            obj
        }
    } catch (_: Exception) { null }

    private fun executeActions(actions: JSONArray?) {
        if (actions == null) return
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            when (a.optString("type")) {
                "global" -> NexaAccessibilityService.instance?.action(a.optString("name"))
                "open_app" -> openApp(a.optString("app"))
                "open_url" -> openUrl(a.optString("url"))
                "web_search" -> openUrl("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))
            }
        }
    }

    private fun openApp(app: String) {
        val packageName = mapOf("youtube" to "com.google.android.youtube", "chrome" to "com.android.chrome", "settings" to "com.android.settings", "maps" to "com.google.android.apps.maps", "whatsapp" to "com.whatsapp")[app.lowercase()] ?: return
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }

    private fun openUrl(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }

    private fun addBubble(who: String, text: String, user: Boolean) {
        val tv = TextView(this).apply { this.text = "$who\n$text"; textSize = 16f; setTextColor(ContextCompat.getColor(context, R.color.nexa_text)); setPadding(18, 14, 18, 14) }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 8, 0, 8); chat.addView(tv, lp)
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexa-${System.currentTimeMillis()}") }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) { tts?.language = Locale.getDefault(); tts?.setSpeechRate(0.95f) } }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
