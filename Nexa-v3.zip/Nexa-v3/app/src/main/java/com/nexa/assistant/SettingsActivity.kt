package com.nexa.assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_settings)
        val prefs = getSharedPreferences("nexa", MODE_PRIVATE)
        val url = findViewById<EditText>(R.id.backendUrl); url.setText(prefs.getString("backend_url", ""))
        findViewById<Button>(R.id.saveButton).setOnClickListener { prefs.edit().putString("backend_url", url.text.toString().trim().trimEnd('/')).apply(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show(); finish() }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }
}
