# Nexa v3

A voice-first Android assistant starter project with:

- Voice input using Android Speech Recognition
- Natural AI replies through a small backend
- Text-to-speech replies
- Conversation history for the current session
- Explicit, allow-listed phone actions
- AccessibilityService controls for Home, Back, Recents, Notifications, Quick Settings, Lock Screen, Screenshot and volume
- Safe app launching for YouTube, Chrome, Settings, Maps and WhatsApp
- Web search action through the normal browser
- Backend URL configurable inside the app

## Important
Android does **not** allow an ordinary app to control literally everything. Nexa uses user-enabled AccessibilityService features for supported system actions. The user must enable the service manually in Android Settings.

Keep the AI API key on the backend. Do not put it in the Android APK.

## Build Android app
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect your Android phone with USB debugging enabled.
4. Run the `app` configuration.
5. Open Nexa > Settings and enter your backend URL.
6. Tap **Enable phone control** and enable Nexa in Accessibility settings.
7. Return to Nexa and use the microphone.

## Run backend
Requires Node.js 20+.

```bash
cd backend
npm install
cp .env.example .env
# Put your API key in .env; never commit it.
npm start
```

For a physical phone, `http://localhost:8787` means the phone itself, not your computer. Use a reachable HTTPS server or your computer's LAN IP while both devices are on the same network. For production, use HTTPS and authentication.

## Example commands
- "Open YouTube"
- "Go home"
- "Go back"
- "Open quick settings"
- "Turn the volume up"
- "Search the web for today's weather in Bengaluru"
- "What is photosynthesis?"

The backend uses OpenAI's Responses API. The older Assistants API was sunset on August 26, 2026, so this project intentionally uses Responses instead.
