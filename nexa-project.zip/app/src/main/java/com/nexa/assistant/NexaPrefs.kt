package com.nexa.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Private on-device storage for settings and the current chat session. No secrets from the AI provider live here. */
object NexaPrefs {
    private const val FILE = "nexa_settings"
    private const val MAX_SAVED = 40

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun backendUrl(context: Context): String = prefs(context).getString("backend_url", "") ?: ""

    fun accessToken(context: Context): String = prefs(context).getString("access_token", "") ?: ""

    fun save(context: Context, url: String, token: String) {
        prefs(context).edit()
            .putString("backend_url", url.trim())
            .putString("access_token", token.trim())
            .apply()
    }

    fun sessionId(context: Context): String {
        val p = prefs(context)
        val existing = p.getString("session_id", null)
        if (existing != null) return existing
        val created = UUID.randomUUID().toString()
        p.edit().putString("session_id", created).apply()
        return created
    }

    fun loadHistory(context: Context): MutableList<ChatMessage> {
        val list = mutableListOf<ChatMessage>()
        val raw = prefs(context).getString("history", null) ?: return list
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                list.add(ChatMessage(o.getString("role"), o.getString("content")))
            }
        } catch (e: Exception) {
            list.clear()
        }
        return list
    }

    fun saveHistory(context: Context, history: List<ChatMessage>) {
        val array = JSONArray()
        for (m in history.takeLast(MAX_SAVED)) {
            val o = JSONObject()
            o.put("role", m.role)
            o.put("content", m.content)
            array.put(o)
        }
        prefs(context).edit().putString("history", array.toString()).apply()
    }

    fun clearSession(context: Context) {
        prefs(context).edit().remove("history").remove("session_id").apply()
    }
}
