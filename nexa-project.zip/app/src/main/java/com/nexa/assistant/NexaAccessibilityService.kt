package com.nexa.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Only used to perform global actions (Home, Back, Recents, Notifications, Quick Settings)
 * after the user explicitly turns this service on in Android Accessibility settings.
 * It does not read screen content (canRetrieveWindowContent is false).
 */
class NexaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty: Nexa does not observe screen events.
    }

    override fun onInterrupt() {
        // Nothing to interrupt.
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: NexaAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun perform(action: Int): Boolean = instance?.performGlobalAction(action) ?: false
    }
}
