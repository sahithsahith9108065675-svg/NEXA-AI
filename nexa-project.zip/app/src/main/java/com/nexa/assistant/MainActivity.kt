package com.nexa.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var scrollView: ScrollView
    private lateinit var messagesLayout: LinearLayout
    private lateinit var inputField: EditText
    private lateinit var statusText: TextView
    private lateinit var micButton: Button
    private lateinit var accessButton: Button

    private lateinit var voiceIn: VoiceInput
    private lateinit var voiceOut: VoiceOutput
    private lateinit var router: CommandRouter

    private val chat = ChatClient()
    private val history = mutableListOf<ChatMessage>()
    private var listening = false
    private var busy = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else setStatus(getString(R.string.status_mic_denied))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scrollView = findViewById(R.id.scrollView)
        messagesLayout = findViewById(R.id.messagesLayout)
        inputField = findViewById(R.id.inputField)
        statusText = findViewById(R.id.statusText)
        micButton = findViewById(R.id.micButton)
        accessButton = findViewById(R.id.accessButton)
        val sendButton = findViewById<Button>(R.id.sendButton)
        val settingsButton = findViewById<Button>(R.id.settingsButton)
        val newSessionButton = findViewById<Button>(R.id.newSessionButton)

        router = CommandRouter(this)
        voiceOut = VoiceOutput(this)
        voiceIn = VoiceInput(this, object : VoiceInput.Listener {
            override fun onPartial(text: String) {
                setStatus(text)
            }

            override fun onResult(text: String) {
                setStatus(getString(R.string.status_ready))
                handleUserText(text)
            }

            override fun onError(message: String) {
                setStatus(message)
            }

            override fun onStateChanged(listening: Boolean) {
                setListening(listening)
            }
        })

        history.addAll(NexaPrefs.loadHistory(this))
        if (history.isEmpty()) {
            addBubble(getString(R.string.welcome), false)
        } else {
            for (m in history) addBubble(m.content, m.role == "user")
        }

        micButton.setOnClickListener { onMicClicked() }
        sendButton.setOnClickListener { submitTyped() }
        settingsButton.setOnClickListener { showSettings() }
        newSessionButton.setOnClickListener { newSession() }
        accessButton.setOnClickListener { onAccessClicked() }
    }

    override fun onResume() {
        super.onResume()
        accessButton.setText(
            if (NexaAccessibilityService.isEnabled()) R.string.access_on else R.string.access_off
        )
    }

    override fun onStop() {
        super.onStop()
        if (listening) {
            voiceIn.stop()
            setListening(false)
        }
    }

    override fun onDestroy() {
        voiceIn.stop()
        voiceOut.shutdown()
        super.onDestroy()
    }

    // ---------- voice ----------

    private fun onMicClicked() {
        if (listening) {
            voiceIn.stop()
            setListening(false)
            setStatus(getString(R.string.status_ready))
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        voiceOut.stop()
        if (!voiceIn.isAvailable()) {
            setStatus(getString(R.string.status_no_recognizer))
            return
        }
        voiceIn.start()
    }

    private fun setListening(on: Boolean) {
        listening = on
        micButton.setText(if (on) R.string.mic_listening else R.string.mic_idle)
    }

    // ---------- conversation ----------

    private fun submitTyped() {
        val text = inputField.text.toString()
        inputField.setText("")
        handleUserText(text)
    }

    private fun handleUserText(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        addBubble(text, true)
        when (val outcome = router.handle(text)) {
            is CommandRouter.Outcome.Handled -> reply(outcome.spoken)
            is CommandRouter.Outcome.NotACommand -> askAi(text)
        }
    }

    private fun reply(text: String) {
        addBubble(text, false)
        voiceOut.speak(text)
    }

    private fun askAi(text: String) {
        if (busy) {
            setStatus(getString(R.string.status_thinking))
            return
        }
        val url = NexaPrefs.backendUrl(this)
        if (!url.startsWith("https://")) {
            reply(getString(R.string.setup_needed))
            return
        }

        history.add(ChatMessage("user", text))
        busy = true
        setStatus(getString(R.string.status_thinking))

        chat.send(
            url,
            NexaPrefs.accessToken(this),
            NexaPrefs.sessionId(this),
            history.toList()
        ) { result ->
            busy = false
            setStatus(getString(R.string.status_ready))
            result.onSuccess { answer ->
                history.add(ChatMessage("assistant", answer))
                trimHistory()
                NexaPrefs.saveHistory(this, history)
                reply(answer)
            }
            result.onFailure { error ->
                if (history.isNotEmpty() && history.last().role == "user") {
                    history.removeAt(history.lastIndex)
                }
                reply("Sorry, I could not reach my backend. ${error.message ?: ""}".trim())
            }
        }
    }

    private fun trimHistory() {
        while (history.size > 20) history.removeAt(0)
        while (history.isNotEmpty() && history[0].role != "user") history.removeAt(0)
    }

    private fun newSession() {
        voiceOut.stop()
        history.clear()
        NexaPrefs.clearSession(this)
        messagesLayout.removeAllViews()
        addBubble(getString(R.string.welcome), false)
    }

    // ---------- UI helpers ----------

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun addBubble(text: String, fromUser: Boolean) {
        val bubble = TextView(this)
        bubble.text = text
        bubble.textSize = 16f
        bubble.setTextColor(ContextCompat.getColor(this, R.color.nexa_text))
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10))
        bubble.setBackgroundResource(if (fromUser) R.drawable.bubble_user else R.drawable.bubble_nexa)
        bubble.setTextIsSelectable(true)

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = dp(6)
        params.bottomMargin = dp(6)
        if (fromUser) {
            params.gravity = Gravity.END
            params.marginStart = dp(48)
        } else {
            params.gravity = Gravity.START
            params.marginEnd = dp(48)
        }
        messagesLayout.addView(bubble, params)
        scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showSettings() {
        val pad = dp(20)
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(pad, dp(8), pad, 0)

        val urlField = EditText(this)
        urlField.hint = getString(R.string.hint_backend_url)
        urlField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlField.setSingleLine()
        urlField.setText(NexaPrefs.backendUrl(this))

        val tokenField = EditText(this)
        tokenField.hint = getString(R.string.hint_access_token)
        tokenField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        tokenField.setSingleLine()
        tokenField.setText(NexaPrefs.accessToken(this))

        container.addView(urlField)
        container.addView(tokenField)

        AlertDialog.Builder(this)
            .setTitle(R.string.settings_title)
            .setView(container)
            .setPositiveButton(R.string.save) { _, _ ->
                NexaPrefs.save(this, urlField.text.toString(), tokenField.text.toString())
                setStatus(getString(R.string.status_saved))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onAccessClicked() {
        if (NexaAccessibilityService.isEnabled()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.access_title)
            .setMessage(R.string.access_message)
            .setPositiveButton(R.string.access_continue) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
