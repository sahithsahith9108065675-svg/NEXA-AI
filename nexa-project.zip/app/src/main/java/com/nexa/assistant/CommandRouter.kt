package com.nexa.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.util.Locale

/** Handles local voice commands (open apps, Home/Back/Recents/Notifications). Everything else goes to the AI. */
class CommandRouter(private val context: Context) {

    sealed class Outcome {
        data class Handled(val spoken: String) : Outcome()
        object NotACommand : Outcome()
    }

    private class KnownApp(val label: String, val packageName: String?, val fallbackUri: String?)

    private val youtube = KnownApp("YouTube", "com.google.android.youtube", "https://www.youtube.com")
    private val chrome = KnownApp("Chrome", "com.android.chrome", "https://www.google.com")
    private val maps = KnownApp("Maps", "com.google.android.apps.maps", "https://maps.google.com")
    private val settingsApp = KnownApp("Settings", null, null)

    private val knownApps: Map<String, KnownApp> = mapOf(
        "youtube" to youtube,
        "you tube" to youtube,
        "chrome" to chrome,
        "google chrome" to chrome,
        "maps" to maps,
        "google maps" to maps,
        "map" to maps,
        "settings" to settingsApp,
        "setting" to settingsApp,
        "phone settings" to settingsApp
    )

    fun handle(raw: String): Outcome {
        val text = normalize(raw)
        if (text.isEmpty()) return Outcome.NotACommand

        val control = deviceControl(text)
        if (control != null) return control

        val match = OPEN_REGEX.matchEntire(text) ?: return Outcome.NotACommand
        val name = match.groupValues[2].removePrefix("the ").removeSuffix(" app").trim()
        if (name.isEmpty()) return Outcome.NotACommand
        return openApp(name, text)
    }

    private fun normalize(raw: String): String {
        var t = raw.lowercase(Locale.ROOT).replace(",", " ").replace(Regex("\\s+"), " ").trim()
        t = t.trimEnd('.', '!', '?').trim()
        var changed = true
        while (changed) {
            changed = false
            for (p in PREFIXES) {
                if (t.startsWith("$p ")) {
                    t = t.substring(p.length).trim()
                    changed = true
                }
            }
            if (t.endsWith(" please")) {
                t = t.removeSuffix(" please").trim()
                changed = true
            }
        }
        return t
    }

    private fun deviceControl(t: String): Outcome? {
        val action: Int
        val message: String
        when {
            t.contains("quick settings") -> {
                action = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                message = "Opening quick settings"
            }
            t in HOME_PHRASES -> {
                action = AccessibilityService.GLOBAL_ACTION_HOME
                message = "Going home"
            }
            t in BACK_PHRASES -> {
                action = AccessibilityService.GLOBAL_ACTION_BACK
                message = "Going back"
            }
            t in RECENTS_PHRASES -> {
                action = AccessibilityService.GLOBAL_ACTION_RECENTS
                message = "Showing recent apps"
            }
            t in NOTIFICATION_PHRASES -> {
                action = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                message = "Opening notifications"
            }
            else -> return null
        }
        if (!NexaAccessibilityService.isEnabled()) {
            return Outcome.Handled(
                "Device controls are off. Tap Enable device controls on the main screen first."
            )
        }
        return if (NexaAccessibilityService.perform(action)) {
            Outcome.Handled(message)
        } else {
            Outcome.Handled("Sorry, Android did not allow that action.")
        }
    }

    private fun openApp(name: String, fullText: String): Outcome {
        val known = knownApps[name]
        if (known != null) {
            return if (launchKnown(known)) {
                Outcome.Handled("Opening ${known.label}")
            } else {
                Outcome.Handled("Sorry, I could not open ${known.label}.")
            }
        }

        val found = findInstalled(name)
        if (found != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(found.second)
            if (launch != null && start(launch)) {
                return Outcome.Handled("Opening ${found.first}")
            }
        }

        // Short "open <something>" that we cannot find: say so. Longer sentences go to the AI.
        return if (fullText.split(" ").size <= 4) {
            Outcome.Handled("Sorry, I could not find an app called $name.")
        } else {
            Outcome.NotACommand
        }
    }

    private fun launchKnown(app: KnownApp): Boolean {
        if (app === settingsApp) {
            return start(Intent(Settings.ACTION_SETTINGS))
        }
        val pkg = app.packageName
        if (pkg != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null && start(launch)) return true
        }
        val uri = app.fallbackUri
        return uri != null && start(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
    }

    /** Returns (label, packageName) of an installed launcher app whose name matches. */
    private fun findInstalled(name: String): Pair<String, String>? {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
        var best: Pair<String, String>? = null
        for (info in apps) {
            val label = info.loadLabel(pm).toString()
            val lower = label.lowercase(Locale.ROOT)
            val pkg = info.activityInfo.packageName
            if (lower == name) return Pair(label, pkg)
            if (best == null && lower.contains(name)) best = Pair(label, pkg)
        }
        return best
    }

    private fun start(intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        private val OPEN_REGEX = Regex("^(open|launch)\\s+(.+)$")

        private val PREFIXES = listOf(
            "hey nexa", "ok nexa", "okay nexa", "nexa",
            "please", "can you", "could you", "would you"
        )

        private val HOME_PHRASES = setOf(
            "home", "go home", "go to home", "home screen", "go to the home screen",
            "go to home screen", "show home screen", "press home", "take me home"
        )
        private val BACK_PHRASES = setOf("back", "go back", "press back", "navigate back")
        private val RECENTS_PHRASES = setOf(
            "recents", "recent apps", "show recent apps", "open recents", "open recent apps",
            "show recents", "app switcher", "show app switcher"
        )
        private val NOTIFICATION_PHRASES = setOf(
            "notifications", "open notifications", "show notifications", "show my notifications",
            "pull down notifications", "open notification panel", "open notification shade"
        )
    }
}
