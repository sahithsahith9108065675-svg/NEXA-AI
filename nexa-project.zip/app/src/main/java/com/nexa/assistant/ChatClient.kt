package com.nexa.assistant

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class ChatMessage(val role: String, val content: String)

/**
 * Talks to YOUR backend (see backend/worker.js). The app never contains an AI API key.
 * The callback is always delivered on the main thread.
 */
class ChatClient {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun send(
        backendUrl: String,
        accessToken: String,
        sessionId: String,
        messages: List<ChatMessage>,
        onResult: (Result<String>) -> Unit
    ) {
        executor.execute {
            val result = runCatching { post(backendUrl, accessToken, sessionId, messages) }
            mainHandler.post { onResult(result) }
        }
    }

    private fun post(
        backendUrl: String,
        accessToken: String,
        sessionId: String,
        messages: List<ChatMessage>
    ): String {
        val payload = JSONObject()
        payload.put("sessionId", sessionId)
        val array = JSONArray()
        for (m in messages) {
            val item = JSONObject()
            item.put("role", m.role)
            item.put("content", m.content)
            array.put(item)
        }
        payload.put("messages", array)

        val connection = URL(backendUrl).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15000
            connection.readTimeout = 60000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (accessToken.isNotBlank()) {
                connection.setRequestProperty("Authorization", "Bearer $accessToken")
            }
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                throw IOException("Server returned error $code")
            }
            val reply = JSONObject(body).optString("reply", "").trim()
            if (reply.isEmpty()) throw IOException("Empty reply from server")
            return reply
        } finally {
            connection.disconnect()
        }
    }
}
