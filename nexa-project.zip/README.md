# Nexa

Android voice assistant (Kotlin). No API keys are stored in this repo or in the app.

- `app/` Android app
- `backend/worker.js` Cloudflare Worker that holds the AI key as a secret
- `.github/workflows/build.yml` builds a debug APK (Actions tab, Artifacts)

In the app: Settings, then enter your Worker URL and access token.
