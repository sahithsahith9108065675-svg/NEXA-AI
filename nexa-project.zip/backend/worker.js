// Nexa backend: Cloudflare Worker. Holds the AI API key as a SECRET (never in the app or in GitHub).
// Required secrets (set in the Cloudflare dashboard):  ANTHROPIC_API_KEY, NEXA_APP_TOKEN
// Optional variable: MODEL (defaults to claude-sonnet-5-5)

const SYSTEM_PROMPT =
  "You are Nexa, a friendly voice assistant on an Android phone. " +
  "Your replies are spoken aloud, so keep them short (one to three sentences), natural and conversational. " +
  "Use plain text only: no markdown, no bullet lists, no emojis unless asked. " +
  "The app itself handles commands like opening apps and Home, Back, Recents and Notifications; " +
  "if the user asks for something you cannot do on the device, say so briefly.";

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

export default {
  async fetch(request, env) {
    if (request.method !== "POST") return json({ error: "POST only" }, 405);

    const auth = request.headers.get("Authorization") || "";
    if (!env.NEXA_APP_TOKEN || auth !== "Bearer " + env.NEXA_APP_TOKEN) {
      return json({ error: "Unauthorized" }, 401);
    }
    if (!env.ANTHROPIC_API_KEY) return json({ error: "Server not configured" }, 500);

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return json({ error: "Invalid JSON" }, 400);
    }

    let messages = Array.isArray(body.messages) ? body.messages : [];
    messages = messages
      .filter(
        (m) =>
          m &&
          (m.role === "user" || m.role === "assistant") &&
          typeof m.content === "string" &&
          m.content.trim() !== ""
      )
      .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }))
      .slice(-20);
    while (messages.length && messages[0].role !== "user") messages.shift();
    if (!messages.length) return json({ error: "No messages" }, 400);

    let upstream;
    try {
      upstream = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: env.MODEL || "claude-sonnet-5-5",
          max_tokens: 400,
          system: SYSTEM_PROMPT,
          messages,
        }),
      });
    } catch (e) {
      return json({ error: "Upstream unreachable" }, 502);
    }

    if (!upstream.ok) return json({ error: "Upstream error " + upstream.status }, 502);

    const data = await upstream.json();
    const reply = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .trim();
    return json({ reply: reply || "Sorry, I have nothing to say." });
  },
};
